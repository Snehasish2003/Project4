import React from 'react'
import HeroSection from './HeroSection2'
import Header from './Header'

const Page1 = () => {
  return (
    <section className="w-full lg:h-[880px] ">

    {/* <Header/> */}

    <HeroSection/>

</section>    
  )
}

export default Page1
